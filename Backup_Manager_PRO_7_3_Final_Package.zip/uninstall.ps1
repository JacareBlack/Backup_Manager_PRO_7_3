Remove-Item "C:\Manual_Backup_Manager_PRO_7_3" -Recurse -Force -ErrorAction SilentlyContinue
