Backup Manager PRO 7.3 - Pacote Final

Conteúdo:
- Backup_Manager_PRO_7_3.ps1 (substitua pelo seu script completo 7.3)
- Run_Backup_Manager.cmd
- installer.iss (Inno Setup)
- uninstall.ps1

Para gerar EXE nativo:
1. Instale Inno Setup no Windows
2. Abra installer.iss
3. Compile
Saída: Setup_Backup_Manager_PRO_7_3.exe
