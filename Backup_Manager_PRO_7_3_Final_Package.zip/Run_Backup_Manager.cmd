@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell -Verb RunAs -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File ""C:\Manual_Backup_Manager_PRO_7_3\Backup_Manager_PRO_7_3.ps1""'"
