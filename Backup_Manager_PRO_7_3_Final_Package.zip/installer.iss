#define MyAppName "Backup Manager PRO 7.3"
[Setup]
AppName={#MyAppName}
AppVersion=7.3
DefaultDirName=C:\Manual_Backup_Manager_PRO_7_3
OutputBaseFilename=Setup_Backup_Manager_PRO_7_3
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=admin

[Files]
Source: "Backup_Manager_PRO_7_3.ps1"; DestDir: "{app}"
Source: "Run_Backup_Manager.cmd"; DestDir: "{app}"
Source: "uninstall.ps1"; DestDir: "{app}"

[Icons]
Name: "{autodesktop}\Backup Manager PRO 7.3"; Filename: "{app}\Run_Backup_Manager.cmd"
