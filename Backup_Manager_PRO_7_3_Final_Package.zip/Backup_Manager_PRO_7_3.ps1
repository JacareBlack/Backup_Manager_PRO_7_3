# Cole aqui seu script completo da versão 7.3
